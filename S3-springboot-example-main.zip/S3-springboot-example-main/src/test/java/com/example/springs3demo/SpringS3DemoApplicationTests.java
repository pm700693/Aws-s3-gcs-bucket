package com.example.springs3demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringS3DemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
