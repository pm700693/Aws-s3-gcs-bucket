package com.example.springs3demo.controller;

import com.example.springs3demo.service.FileService;
import com.example.springs3demo.service.S3Service;
import com.google.cloud.storage.BlobId;
import com.google.cloud.storage.BlobInfo;
import com.google.cloud.storage.Storage;
import com.google.cloud.ReadChannel;

import org.apache.logging.log4j.message.Message;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.awt.*;

import java.util.List;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import static java.net.HttpURLConnection.HTTP_OK;

@RestController
public class S3Controller {

	@Value("${download.directory}")
    	private String downloadDirectory;
	
	 private final FileService fileService;
	
	 @Autowired
	    public S3Controller(FileService fileService) {
	        this.fileService = fileService;
	    }
	    
	 
    @Autowired
    private S3Service s3Service;;
    
    @Autowired
    private Storage storage;
    
    @Value("${file.storage}")
    private Resource localFilePath;
    
    

    @PostMapping("upload")
    public String upload(@RequestParam("file") MultipartFile file){
       return s3Service.saveFile(file);
    }
    
    @GetMapping("download/{filename}")
    public ResponseEntity<byte[]> download(@PathVariable("filename") String filename){
        HttpHeaders headers=new HttpHeaders();
      


        headers.add("Content-type", MediaType.ALL_VALUE);
        headers.add("Content-Disposition", "attachment; filename="+filename);
        byte[] bytes = s3Service.downloadFile(filename);
        return  ResponseEntity.status(HTTP_OK).headers(headers).body(bytes);
    }

    @GetMapping("write-file/{fileName}")
    public Message writeFileToBucket(@PathVariable(name="fileName")String fileName) throws Exception{
    	BlobId blobId = BlobId.of("average-weather",fileName);
    	BlobInfo blobInfo = BlobInfo.newBuilder(blobId).build();
    	File fileToRead = new File(localFilePath.getFile(),fileName);
    	byte[] data = Files.readAllBytes(Paths.get(fileToRead.toURI()));
    	storage.create(blobInfo, data);
    	Message message = new Message();
    	message.setContents(new String(data));
    	return message;
    }
    
    @PostMapping("/uploadtogcs")
    public String uploadFileToGCS(@RequestParam String url, @RequestParam String bucketName, @RequestParam String objectName) {
        try {
            fileService.downloadAndUploadFile(url, bucketName, objectName);
            return "File uploaded to GCS successfully";
        } catch (IOException e) {
            return "Error uploading file to GCS: " + e.getMessage();
        }
    }


    @DeleteMapping("{filename}")
    public  String deleteFile(@PathVariable("filename") String filename){
       return s3Service.deleteFile(filename);
    }

    @GetMapping("list")
    public List<String> getAllFiles(){

        return s3Service.listAllFiles();

    }
    
    class Message {
    	private String contents;

    	public String getContents() {
    		return contents;
    	}

    	public void setContents(String contents) {
    		this.contents = contents;
    	}

    }
}
