package com.example.springs3demo.service;

import org.springframework.stereotype.Service;
import org.springframework.util.StreamUtils;
import org.springframework.web.client.RestTemplate;
import com.google.cloud.storage.Blob;
import com.google.cloud.storage.Storage;
import com.google.cloud.storage.StorageOptions;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

@Service
public class FileService {
    private final RestTemplate restTemplate;
    private final Storage storage;

    public FileService() {
        restTemplate = new RestTemplate();
        storage = StorageOptions.getDefaultInstance().getService();
    }

    public void downloadAndUploadFile(String url, String bucketName, String objectName) throws IOException {
        // Download the file from the URL
        InputStream fileStream = restTemplate.getForObject(url, InputStream.class);

        // Upload the file to Google Cloud Storage
        @SuppressWarnings("deprecation")
		Blob blob = storage.create(
            Blob.newBuilder(bucketName, objectName).build(),
            fileStream
        );

        fileStream.close();

        System.out.println("File uploaded to GCS with URL: " + blob.getMediaLink());
    }
}
